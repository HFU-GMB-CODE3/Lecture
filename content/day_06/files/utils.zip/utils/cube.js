export default class Cube {
    constructor(size, mode = 'random') {
        this.size = size;
        this.vertices = this.generateVertices();
        this.indices = this.generateIndices();
        this.colors = this.generateColors(mode);
        this.normals = this.generateNormals();
        this.texcoords = this.generateTexcoords();
    }
    /**
     * Generates the vertices for a cube.
     * @returns {number[]} An array of vertex positions.
     */
    generateVertices() {
        const half = this.size / 2;
        return [
            // Front face
            -half, -half, half,
            half, -half, half,
            half, half, half,
            -half, half, half,

            // Back face
            -half, -half, -half,
            -half, half, -half,
            half, half, -half,
            half, -half, -half,

            // Top face
            -half, half, -half,
            -half, half, half,
            half, half, half,
            half, half, -half,

            // Bottom face
            -half, -half, -half,
            half, -half, -half,
            half, -half, half,
            -half, -half, half,

            // Right face
            half, -half, -half,
            half, half, -half,
            half, half, half,
            half, -half, half,

            // Left face
            -half, -half, -half,
            -half, -half, half,
            -half, half, half,
            -half, half, -half,
        ];
    }

    generateIndices() {
        return [
            // Front face
            0, 1, 2,
            0, 2, 3,

            // Back face
            4, 5, 6,
            4, 6, 7,

            // Top face
            8, 9, 10,
            8, 10, 11,

            // Bottom face
            12, 13, 14,
            12, 14, 15,

            // Right face
            16, 17, 18,
            16, 18, 19,

            // Left face
            20, 21, 22,
            20, 22, 23,
        ];
    }

    /**
     * Generates random colors for the cube.
     * Each face will have a different color.
     * @returns {number[]} An array of RGBA color values.
     */
    generateColors(mode) {
        if (mode === 'random') {
            const colors = [];
            let numFaces = 6;
            for (let i = 0; i < numFaces; i++) {
                // Each face has 6 vertices, 2 triangles
                // Each vertex has 4 color components (RGBA)
                // color each face with a different color
                let scale = 0.3; // Scale to adjust color brightness
                let offset = 0.0; // Offset to adjust color brightness
                let color = [Math.random() * scale + offset, Math.random() * scale + offset, Math.random() * scale + offset, 1.0];
                colors.push(
                    ...color,
                    ...color,
                    ...color,
                    ...color
                );
            }
            return colors;
        }
        else if (mode === 'white') {
            // White color for all vertices
            const colors = Array(6 * 4 * 4).fill(1.0); // 6 faces * 4 vertices per face * 4 components (RGBA)
            return colors;
        } else {
            throw new Error('Unknown color mode');
        }
    }

    generateNormals() {
        const normals = [];
        let front = [0, 0, 1]; // Front face normal
        let back = [0, 0, -1]; // Back face normal
        let top = [0, 1, 0]; // Top face normal
        let bottom = [0, -1, 0]; // Bottom face normal
        let right = [1, 0, 0]; // Right face normal
        let left = [-1, 0, 0]; // Left face normal
        let numVerticesPerFace = 4; // Each face has 4 vertices
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...front);
        }
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...back);
        }
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...top);
        }
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...bottom);
        }
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...right);
        }
        for (let i = 0; i < numVerticesPerFace; i++) {
            normals.push(...left);
        }
        return normals;
    }

    generateTexcoords() {
        const texcoords = [];
        // front face
        let numFaces = 6; // Each face has 4 vertices
        for (let i = 0; i < numFaces; i++) {
            texcoords.push(...[0, 0]);
            texcoords.push(...[0, 1]);
            texcoords.push(...[1, 1]);
            texcoords.push(...[1, 0]);
        }
        return texcoords;
    }
}